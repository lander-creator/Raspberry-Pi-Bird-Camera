OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Kullanıcı adı",
    "Password" : "Parola",
    "Host" : "Sunucu",
    "Root" : "Kök",
    "Port" : "Port",
    "Secure ftps://" : "Güvenli ftps://"
},
"nplurals=2; plural=(n > 1);");
