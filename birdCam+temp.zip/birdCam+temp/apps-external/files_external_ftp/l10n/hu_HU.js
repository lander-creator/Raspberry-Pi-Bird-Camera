OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Felhő)",
    "Username" : "Felhasználónév",
    "Password" : "Jelszó",
    "Host" : "Kiszolgáló",
    "Root" : "Gyökér",
    "Port" : "Port",
    "Secure ftps://" : "Biztonságos ftps://"
},
"nplurals=2; plural=(n != 1);");
