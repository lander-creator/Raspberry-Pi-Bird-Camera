OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "用户名",
    "Password" : "密码",
    "Host" : "主机",
    "Root" : "根路径",
    "Port" : "端口",
    "Secure ftps://" : "安全 ftps://"
},
"nplurals=1; plural=0;");
