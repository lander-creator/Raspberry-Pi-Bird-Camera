OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Volar)",
    "Username" : "Nome d'usuariu",
    "Password" : "Contraseña",
    "Host" : "Sirvidor",
    "Root" : "Raíz",
    "Port" : "Puertu",
    "Secure ftps://" : "Secure ftps://"
},
"nplurals=2; plural=(n != 1);");
