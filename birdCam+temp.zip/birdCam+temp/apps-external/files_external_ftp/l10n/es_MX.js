OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (al vuelo)",
    "Username" : "Nombre de usuario",
    "Password" : "Contraseña",
    "Host" : "Servidor",
    "Root" : "Raíz",
    "Port" : "Puerto",
    "Secure ftps://" : "Seguro ftps://"
},
"nplurals=2; plural=(n != 1);");
