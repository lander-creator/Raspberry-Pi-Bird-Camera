OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Gebruikersnaam",
    "Password" : "Wagwoord",
    "Host" : "Gasheer",
    "Root" : "Wortel",
    "Port" : "Poort",
    "Secure ftps://" : "Beveiligde ftps://"
},
"nplurals=2; plural=(n != 1);");
