OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Brukernavn",
    "Password" : "Passord",
    "Host" : "Server",
    "Root" : "Rot",
    "Port" : "Port",
    "Secure ftps://" : "Sikker ftps://"
},
"nplurals=2; plural=(n != 1);");
