OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "ユーザー名",
    "Password" : "パスワード",
    "Host" : "ホスト",
    "Root" : "ルート",
    "Port" : "ポート",
    "Secure ftps://" : "Secure ftps://"
},
"nplurals=1; plural=0;");
