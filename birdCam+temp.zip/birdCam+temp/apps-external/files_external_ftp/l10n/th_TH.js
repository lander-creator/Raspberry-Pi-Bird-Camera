OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "ชื่อผู้ใช้",
    "Password" : "รหัสผ่าน",
    "Host" : "โฮสต์",
    "Root" : "รูท",
    "Port" : "พอร์ต",
    "Secure ftps://" : "โหมดปลอดภัย ftps://"
},
"nplurals=1; plural=0;");
