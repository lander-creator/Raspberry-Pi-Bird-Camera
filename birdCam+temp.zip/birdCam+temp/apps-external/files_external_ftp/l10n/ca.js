OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Vola)",
    "Username" : "Nom d'usuari",
    "Password" : "Contrasenya",
    "Host" : "Equip remot",
    "Root" : "Arrel",
    "Port" : "Port",
    "Secure ftps://" : "Protocol segur ftps://"
},
"nplurals=2; plural=(n != 1);");
