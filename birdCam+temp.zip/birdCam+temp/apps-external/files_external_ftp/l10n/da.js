OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Brugernavn",
    "Password" : "Kodeord",
    "Host" : "Vært",
    "Root" : "Root",
    "Port" : "Port",
    "Secure ftps://" : "Sikker ftps://"
},
"nplurals=2; plural=(n != 1);");
