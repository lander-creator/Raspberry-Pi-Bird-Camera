OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Benutzername",
    "Password" : "Passwort",
    "Host" : "Host",
    "Root" : "Root",
    "Port" : "Port",
    "Secure ftps://" : "Sicherer ftps://"
},
"nplurals=2; plural=(n != 1);");
