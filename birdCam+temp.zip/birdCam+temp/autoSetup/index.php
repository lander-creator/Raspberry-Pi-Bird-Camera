<!DOCTYPE html>
<html>
<head>

<script>
function startTime() {
  var today = new Date();
  var h = today.getHours();
  var m = today.getMinutes();
  var s = today.getSeconds();
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById('txt').innerHTML =
  h + ":" + m + ":" + s;
  var t = setTimeout(startTime, 500);
}
function checkTime(i) {
  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
  return i;
}
</script>
<style>
table {
font-family: "Comic Sans MS", cursive, sans-serif;
        border-collapse: collapse;
        width: 100%;
}

td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
}

tr:nth-child(even) {
        background-color: #dddddd;
}
</style>
</head>
<center><h1>Value Logger</h1>
<body onload="startTime()">
<div id="txt"></div>
<br />
<A HREF="javascript:history.go(0)">Click to refresh the page</A>
<br />
<H2 align="left">Temperature</h2>
 <div style="width:1400px;height:385px;line-height:3em;overflow:auto;padding:5px;">
<?php
        $db = new SQLite3("/var/www/mywebsite.be/database/templog.db");
        $res = $db->query('select * FROM dsreading');
        echo '<table width="40%" border="1">';

        echo '<td>nummer </td>';
        echo '<td>temperatuur (°C) </td>';
        echo '<td>datum </td>';
        echo '<td>tijd </td>';
        echo '<td>type sensor </td>';

        while ($row = $res->fetchArray()) {
                echo '<tr>';
                echo "<td> {$row['id']} </td>";
                echo "<td> {$row['temperature']} </td>";
                echo "<td> {$row['currentdate']} </td>";
                echo "<td> {$row['currenttime']} </td>";
                echo "<td> {$row['device']} </td>";
                echo '</tr>';
}
echo '</table>';
?>

</div>
</body>
</html>

