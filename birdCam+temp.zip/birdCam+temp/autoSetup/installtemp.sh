#!/bin/bash

# Install packages
echo "*** update & upgrade"
sudo apt-get update
sudo apt-get upgrade -y

# Install python3
echo "*** install python3"
sudo apt install python3-pip

# Install apache2
echo "*** install apache2"
sudo apt-get install apache2 sqlite -y
sudo apt-get install sqlite3 -y
sudo apt-get install php7.3 php7.3-gd php7.3-sqlite3 php7.3-curl libapache2-mod-php -y
sudo apt-get install php php-gd php-sqlite3 php-curl libapache2-mod-php -y
sudo apt-get install smbclient -y
sudo apt install -y apache2 mariadb-server libapache2-mod-php7.3 php7.3-gd php7.3-json php7.3-mysql php7.3-curl php7.3-intl php7.3-mcrypt php-imagick php7.3-zip php7.3-xml php7.3-mbstring
sudo apt-get install php-mysql php-mbstring php-gettext php-intl php-redis php-imagick php-igbinary php-gmp php-curl php-gd php-zip php-imap php-ldap php-bz2 php-phpseclib php-xml -y
sudo systemctl enable apache2
sudo apt-get install php-sqlite3

echo "*** create /var/www/mywebsite.be***"
sudo mkdir /var/www/mywebsite.be
sudo chmod -R 755 /var/www/mywebsite.be
sudo chown -R $USER:$USER /var/www/mywebsite.be
sudo cp /home/pi/autoSetup/index.html /var/www/mywebsite.be
sudo cp /home/pi/autoSetup/mywebsite.conf /etc/apache2/sites-available
sudo a2ensite mywebsite.conf
sudo a2dissite 000-default.conf
sudo apache2ctl configtest
sudo systemctl restart apache2
sudo mkdir /var/www/mywebsite.be/database
sudo cp /home/pi/autoSetup/index.php /var/www/mywebsite.be/database
sudo systemctl restart apache2
cd /var/www/mywebsite.be/database
sudo wget https://bitbucket.org/phpliteadmin/public/downloads/phpLiteAdmin_v1-9-7-1.zip
sudo unzip phpLiteAdmin_v1-9-7-1.zip
sudo rm phpLiteAdmin_v1-9-7-1.zip
sudo mv phpliteadmin.config.sample.php phpliteadmin.config.php
sudo cp /home/pi/autoSetup/phpliteadmin.config.sample.php /var/www/mywebsite.be/database
sudo cp /home/pi/autoSetup/templog.db /var/www/mywebsite.be/database
cd ../
sudo chmod 777 database/
sudo chmod 777 database/*
sudo chown root:root database/
sudo chown root:root database/*
sudo systemctl restart apache2

cd database
cp templog.db ../templog.db
cd ..
ls
sudo rm index.html
sudo cp /home/pi/autoSetup/index.php /var/www/mywebsite.be
sudo systemctl restart apache2
sudo cp /home/pi/autoSetup/sql.py /home/pi
echo "***done, go to your ip adress***"
