import sqlite3
import os
import glob
import time

os.system('modprobe w1-gpio')
os.system('modprobe w1-therm')

base_dir = '/sys/bus/w1/devices/'
device_folder = glob.glob(base_dir + '28*')[0]
device_file = device_folder + '/w1_slave'

def read_temp_raw():
	f = open(device_file, 'r')
	lines = f.readlines()
	f.close()
	return lines

def read_temp():
	lines = read_temp_raw()
	while lines[0].strip()[-3:] != 'YES':
		time.sleep(0.2)
		lines = read_temp_raw()
	equals_pos = lines[1].find('t=')
	if equals_pos != -1:
		temp_string = lines[1][equals_pos+2:]
		temp_c = float(temp_string) / 1000.0
		return temp_c

while True:
	tempvalue = read_temp()
	print(tempvalue)

	def insertVariable(Temp, type):
		try:
			sqliteConnection = sqlite3.connect('/var/www/Log/database/templog.db')
			cursor = sqliteConnection.cursor()
			print("Successfully Connected to SQLite")

			sqlite_insert_query = """insert into dsreading(temperature, currentdate, currenttime, device) values(?, date('now'), time('now'),?);"""
			data_tuple = (Temp, type)

			count = cursor.execute(sqlite_insert_query, data_tuple)
			sqliteConnection.commit()
			print("query succes")
			cursor.close()

		except sqlite3.Error as error:
			print("Failed to insert data into sqlite table", error)
		finally:
			if (sqliteConnection):
				sqliteConnection.close()
				print("The SQLite connection is closed")
	insertVariable(tempvalue,'ds18b20' )
	time.sleep(300)
