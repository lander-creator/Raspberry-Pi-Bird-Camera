OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Användarnamn",
    "Password" : "Lösenord",
    "Host" : "Server",
    "Root" : "Root",
    "Port" : "Port",
    "Secure ftps://" : "Säker ftps://"
},
"nplurals=2; plural=(n != 1);");
