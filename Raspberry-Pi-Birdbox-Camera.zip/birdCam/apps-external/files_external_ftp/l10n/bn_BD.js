OC.L10N.register(
    "files_external_ftp",
    {
    "Username" : "ব্যবহারকারী",
    "Password" : "কূটশব্দ",
    "Host" : "হোস্ট",
    "Root" : "শেকড়",
    "Port" : "পোর্ট",
    "Secure ftps://" : "ftps:// অর্জন কর"
},
"nplurals=2; plural=(n != 1);");
